module.exports = {
  "domain": "https://www.tuandr.com",
  "domain_wap": "https://www.tuandr.com",
  "pathList": [
    "pages/index/index",
    "pages/category/index",
    "pages/shop/list/index",
    "pages/shopcart/index",
    "pages/member/index"
  ],
  "website_id": 1,
  "auth_id": 1
}