var requestSign = require('../../../../utils/requestData.js');
var re = require('../../../../utils/request.js');
var api = require('../../../../utils/api.js').open_api;
var util = require('../../../../utils/util.js');
var header = getApp().header;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    //余额数据
    balanceData:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.myChannelBalance();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  //余额
  myChannelBalance:function(){
    const that = this;
    let postData = {}
    let datainfo = requestSign.requestSign(postData);
    header.sign = datainfo
    re.request(api.get_MyChannelBalance,postData,header).then(res=>{
      if (res.data.code >= 0) {
        let balanceData = res.data.data;
        that.setData({
          balanceData: balanceData
        })
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none'
        })
      }
    }).catch(err=>{
    console.log(err);
    })
  },

  //跳转到充值页
  onRechargePage: function () {

    let onPageData = {
      url: '/package/pages/property/recharge/index',
      num: 4,
      param: '',
    }
    util.jumpPage(onPageData);
  },
  //跳转到提现页面
  onWithdrawPage: function () {

    let onPageData = {
      url: '/package/pages/property/withdraw/index',
      num: 4,
      param: '',
    }
    util.jumpPage(onPageData);
  }
})