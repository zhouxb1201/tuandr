var requestSign = require('../../../../utils/requestData.js');
var re = require('../../../../utils/request.js');
var api = require('../../../../utils/api.js').open_api;
var util = require('../../../../utils/util.js');
var header = getApp().header;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    card_id:'',
    cardDetail:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    const that = this;
    let card_id = options.card_id;
    that.data.card_id = card_id;
    that.consumerCardDetail();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  consumerCardDetail:function(){
    const that = this;
    let postData = {
      'card_id': that.data.card_id,      
    }
    let datainfo = requestSign.requestSign(postData);
    header.sign = datainfo
    re.request(api.get_consumerCardDetail,postData,header).then(res=>{
      if (res.data.code >= 0) {
        that.setData({
          cardDetail:res.data.data
        })
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none'
        })
      }
    }).catch(err=>{
    console.log(err);
    })
  },

  getWeChatCard:function(){
    const that = this;
    let postData = {
      'cards_id': that.data.card_id,
    }
    let datainfo = requestSign.requestSign(postData);
    header.sign = datainfo
    re.request(api.get_getwxCard,postData,header).then(res=>{
      if (res.data.code >= 0) {          
        that.addCard(res.data.data.cardList)
      } else {
        wx.showToast({
          title: res.data.message,
          icon: 'none'
        })
      }
    }).catch(err=>{
    console.log(err);
    })
  },

  addCard: function (cardList){
    wx.addCard({
      cardList: cardList,
      success(res) {
        console.log(res.cardList) // 卡券添加结果
      }
    })
  }
})