var util = require('./util')
module.exports = {
	// onShareAppMessage(e) {
	// 	const route = getCurrentPages()[getCurrentPages().length - 1].route // 当前路由
	// 	const extend_code = getApp().globalData.extend_code; //推广码
	// 	const title = getApp().globalData.config ? getApp().globalData.config.config.mall_name : '商城首页'
	// 	let path = route
	// 	return {
	// 		path: path,
	// 		title: title,
	// 		imageUrl: '',
	// 	}
	// },
	// onLoad: function (e) {
	// 	console.log(e)
		
	// }
}