// 请求方法
/**
 * url 请求地址
 * data 请求数据
 * header 带有签名信息的请求头
 */


const request = (url,data,header)=>{
  return new Promise((resolve,reject) => {
    wx.request({
      url: url,
      data: data,
      header: header,
      method: 'POST',
      dataType: 'json',
      responseType: 'text',
      success: (res) => {
        var setCookie = res.header['Set-Cookie'];   
        if(setCookie&&setCookie.match(/(PHPSESSID=\S*)/)){
          var cookie = setCookie.match(/(PHPSESSID=\S*)/)[1];
                cookie = cookie.replace(",","");
                cookie = cookie.replace(";", "");         
                wx.setStorageSync("setCookie", cookie)
                getApp().header.Cookie = cookie; 
        }
        resolve(res);               
      },
      fail: (err) => { 
        reject(err);
      }
    })
  })
  
}
module.exports = {
  request
}